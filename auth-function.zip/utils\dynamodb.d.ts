/**
 * DynamoDBにアイテムを保存（Put操作）
 */
export declare function putItem(tableName: string, item: Record<string, any>, autoTimestamp?: boolean): Promise<void>;
/**
 * DynamoDBからアイテムを取得（Get操作）
 */
export declare function getItem<T = Record<string, any>>(tableName: string, key: Record<string, any>): Promise<T | null>;
/**
 * DynamoDBのアイテムを更新（Update操作）
 */
export declare function updateItem(tableName: string, key: Record<string, any>, updates: Record<string, any>, autoTimestamp?: boolean): Promise<void>;
/**
 * DynamoDBテーブルをスキャン（Scan操作）
 */
export declare function scanTable<T = Record<string, any>>(tableName: string, filterExpression?: string, expressionAttributeValues?: Record<string, any>): Promise<T[]>;
/**
 * セッションをSessionsテーブルに保存
 */
export declare function saveSession(sessionId: string, email: string, role: 'user' | 'admin', expiresInSeconds?: number): Promise<void>;
/**
 * セッションをSessionsテーブルから取得
 */
export declare function getSession(sessionId: string): Promise<{
    sessionId: string;
    email: string;
    role: 'user' | 'admin';
    createdAt: number;
    expiresAt: number;
} | null>;
/**
 * アンケート回答をResponsesテーブルに保存
 */
export declare function saveResponse(email: string, responses: Record<string, {
    morning: boolean;
    afternoon: boolean;
    evening: boolean;
}>): Promise<void>;
/**
 * アンケート回答をResponsesテーブルから取得
 */
export declare function getResponse(email: string): Promise<{
    email: string;
    responses: Record<string, {
        morning: boolean;
        afternoon: boolean;
        evening: boolean;
    }>;
    createdAt: string;
    updatedAt: string;
} | null>;
/**
 * すべてのアンケート回答を取得（レポート生成用）
 */
export declare function getAllResponses(): Promise<Array<{
    email: string;
    responses: Record<string, {
        morning: boolean;
        afternoon: boolean;
        evening: boolean;
    }>;
    createdAt: string;
    updatedAt: string;
}>>;
//# sourceMappingURL=dynamodb.d.ts.map