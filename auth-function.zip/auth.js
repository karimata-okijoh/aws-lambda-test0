"use strict";
// 認証Lambda関数
// タスク2.1: 認証ハンドラーのコア実装
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const jwt = __importStar(require("jsonwebtoken"));
const types_1 = require("../types");
const validators_1 = require("../utils/validators");
const constants_1 = require("../utils/constants");
const logger_1 = require("../utils/logger");
const errorHandler_1 = require("../utils/errorHandler");
const security_1 = require("../utils/security");
// パスワードのキャッシュ
let commonPasswordCache = null;
let adminPasswordCache = null;
/**
 * 環境変数の取得（セキュアバージョン）
 * 要件: 7.3
 */
const getPassword = async (type) => {
    // キャッシュチェック
    if (type === 'common' && commonPasswordCache) {
        return commonPasswordCache;
    }
    if (type === 'admin' && adminPasswordCache) {
        return adminPasswordCache;
    }
    // SSMパラメータ名を環境変数から取得
    const paramName = type === 'common'
        ? getEnvVar('COMMON_PASSWORD_PARAM')
        : getEnvVar('ADMIN_PASSWORD_PARAM');
    // SSMから取得
    const password = await (0, security_1.getSecretFromSSM)(paramName);
    // キャッシュに保存
    if (type === 'common') {
        commonPasswordCache = password;
    }
    else {
        adminPasswordCache = password;
    }
    return password;
};
/**
 * 環境変数の取得（セキュアバージョン）
 * 要件: 7.3
 */
const getEnvVar = (key) => {
    return (0, security_1.getSecretFromEnv)(key);
};
/**
 * メールアドレスのドメイン検証
 * 要件: 1.2, 1.8
 */
const validateDomain = (email) => {
    if (!(0, validators_1.isValidDomain)(email)) {
        return {
            valid: false,
            errorCode: types_1.ErrorCode.AUTH_001,
            message: 'このアンケートは社内メンバー専用です'
        };
    }
    return { valid: true };
};
/**
 * パスワード検証
 * 要件: 1.3, 1.4
 */
const validatePassword = async (email, password) => {
    const commonPassword = await getPassword('common');
    const adminPassword = await getPassword('admin');
    // 管理者アカウントの場合
    if (email === constants_1.ADMIN_EMAIL) {
        if (password === adminPassword) {
            return { valid: true, role: 'admin' };
        }
        return {
            valid: false,
            errorCode: types_1.ErrorCode.AUTH_002,
            message: 'メールアドレスまたはパスワードが正しくありません'
        };
    }
    // 一般ユーザーの場合
    if (password === commonPassword) {
        return { valid: true, role: 'user' };
    }
    return {
        valid: false,
        errorCode: types_1.ErrorCode.AUTH_002,
        message: 'メールアドレスまたはパスワードが正しくありません'
    };
};
/**
 * JWTトークン生成
 * 要件: 1.6
 */
const generateToken = (email, role) => {
    const jwtSecret = getEnvVar('JWT_SECRET');
    const now = Math.floor(Date.now() / 1000);
    const payload = {
        email,
        role,
        iat: now,
        exp: now + constants_1.JWT_EXPIRATION
    };
    return jwt.sign(payload, jwtSecret);
};
/**
 * 認証Lambda関数ハンドラー
 * 要件: 1.2, 1.3, 1.4, 1.6, 1.7, 1.8, 7.3
 */
const handler = async (event) => {
    try {
        // リクエストボディのパース
        if (!event.body) {
            return {
                statusCode: constants_1.HTTP_STATUS.BAD_REQUEST,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    role: 'user',
                    message: 'リクエストボディが必要です'
                })
            };
        }
        const request = JSON.parse(event.body);
        let { email, password } = request;
        // 入力検証（空白文字のトリミング後にチェック）
        if (!email || !password || email.trim() === '' || password.trim() === '') {
            return {
                statusCode: constants_1.HTTP_STATUS.BAD_REQUEST,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    role: 'user',
                    message: 'メールアドレスとパスワードは必須です'
                })
            };
        }
        // 空白のトリミング
        email = email.trim();
        password = password.trim();
        // メールアドレスのサニタイズ（要件: 7.5）
        try {
            email = (0, validators_1.sanitizeEmail)(email);
        }
        catch (sanitizeError) {
            (0, logger_1.logInfo)('Email sanitization failed', { email });
            throw new errorHandler_1.AppError(types_1.ErrorCode.VAL_002);
        }
        // ドメイン検証（要件: 1.2, 1.8）
        const domainValidation = validateDomain(email);
        if (!domainValidation.valid) {
            (0, logger_1.logInfo)('Domain validation failed', { email });
            throw new errorHandler_1.AppError(types_1.ErrorCode.AUTH_001);
        }
        // パスワード検証（要件: 1.3, 1.4）
        const passwordValidation = await validatePassword(email, password);
        if (!passwordValidation.valid) {
            (0, logger_1.logInfo)('Password validation failed', { email });
            throw new errorHandler_1.AppError(types_1.ErrorCode.AUTH_002);
        }
        // JWTトークン生成（要件: 1.6, 7.3）
        const token = generateToken(email, passwordValidation.role);
        // 成功ログの記録（要件: 10.2）
        (0, errorHandler_1.logSuccess)('authentication', {
            email,
            role: passwordValidation.role
        });
        // 成功レスポンス（要件: 1.5, 7.4）
        const response = {
            success: true,
            token,
            role: passwordValidation.role
        };
        // レスポンスのセキュリティチェック（要件: 7.4）
        const sanitizedResponse = (0, security_1.sanitizeResponse)(response);
        return {
            statusCode: constants_1.HTTP_STATUS.OK,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify(sanitizedResponse)
        };
    }
    catch (error) {
        // グローバルエラーハンドラーを使用（要件: 1.7, 10.1）
        return await (0, errorHandler_1.globalErrorHandler)(error instanceof errorHandler_1.AppError ? error.errorCode : error, {
            requestId: event.requestContext?.requestId,
            functionName: 'AuthLambda',
            userId: event.body ? JSON.parse(event.body).email : undefined
        });
    }
};
exports.handler = handler;
//# sourceMappingURL=auth.js.map