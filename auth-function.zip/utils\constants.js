"use strict";
// 定数定義
Object.defineProperty(exports, "__esModule", { value: true });
exports.HTTP_STATUS = exports.TIME_SLOTS = exports.RETRY_CONFIG = exports.JWT_EXPIRATION = exports.ALLOWED_DOMAIN = exports.ADMIN_EMAIL = exports.SURVEY_PERIOD = void 0;
/**
 * アンケート期間
 */
exports.SURVEY_PERIOD = {
    START_DATE: '2026-03-15',
    END_DATE: '2026-06-27'
};
/**
 * 管理者メールアドレス
 */
exports.ADMIN_EMAIL = 'karimata@okijoh.co.jp';
/**
 * 許可されたドメイン
 */
exports.ALLOWED_DOMAIN = '@okijoh.co.jp';
/**
 * JWTトークンの有効期限（24時間）
 */
exports.JWT_EXPIRATION = 24 * 60 * 60; // 秒単位
/**
 * DynamoDBリトライ設定
 */
exports.RETRY_CONFIG = {
    MAX_RETRIES: 3,
    RETRY_DELAY_MS: 1000
};
/**
 * 時間帯の定義
 */
exports.TIME_SLOTS = {
    MORNING: 'morning',
    AFTERNOON: 'afternoon',
    EVENING: 'evening'
};
/**
 * HTTPステータスコード
 */
exports.HTTP_STATUS = {
    OK: 200,
    BAD_REQUEST: 400,
    UNAUTHORIZED: 401,
    FORBIDDEN: 403,
    NOT_FOUND: 404,
    INTERNAL_SERVER_ERROR: 500,
    NOT_IMPLEMENTED: 501,
    GATEWAY_TIMEOUT: 504
};
//# sourceMappingURL=constants.js.map