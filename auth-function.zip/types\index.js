"use strict";
// コア型定義ファイル
// TeamViewerアンケートアプリケーションの型定義
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorCode = void 0;
/**
 * エラーコード
 */
var ErrorCode;
(function (ErrorCode) {
    // 認証エラー
    ErrorCode["AUTH_001"] = "AUTH_001";
    ErrorCode["AUTH_002"] = "AUTH_002";
    ErrorCode["AUTH_003"] = "AUTH_003";
    ErrorCode["AUTH_004"] = "AUTH_004";
    ErrorCode["AUTH_005"] = "AUTH_005";
    // 入力検証エラー
    ErrorCode["VAL_001"] = "VAL_001";
    ErrorCode["VAL_002"] = "VAL_002";
    ErrorCode["VAL_003"] = "VAL_003";
    // データストアエラー
    ErrorCode["DB_001"] = "DB_001";
    ErrorCode["DB_002"] = "DB_002";
    ErrorCode["DB_003"] = "DB_003";
    ErrorCode["DB_004"] = "DB_004";
    // 期間制約エラー
    ErrorCode["PERIOD_001"] = "PERIOD_001";
    ErrorCode["PERIOD_002"] = "PERIOD_002";
    // システムエラー
    ErrorCode["SYS_001"] = "SYS_001";
    ErrorCode["SYS_002"] = "SYS_002";
    ErrorCode["SYS_003"] = "SYS_003"; // 予期しないエラー
})(ErrorCode || (exports.ErrorCode = ErrorCode = {}));
//# sourceMappingURL=index.js.map