import { ErrorCode, ErrorResponse } from '../types';
/**
 * エラータイプ
 */
export declare enum ErrorType {
    AuthenticationError = "AuthenticationError",
    ValidationError = "ValidationError",
    DataStoreError = "DataStoreError",
    PeriodConstraintError = "PeriodConstraintError",
    SystemError = "SystemError"
}
/**
 * エラー情報
 */
export interface ErrorInfo {
    code: ErrorCode;
    type: ErrorType;
    httpStatus: number;
    userMessage: string;
    context?: Record<string, unknown>;
}
/**
 * エラー分類ロジック
 * エラーオブジェクトまたはエラーコードからエラー情報を生成
 * 要件: 10.1
 */
export declare const classifyError: (error: Error | ErrorCode, context?: Record<string, unknown>) => ErrorInfo;
/**
 * エラーログの記録
 * CloudWatch Logsに構造化ログとして記録
 * 要件: 10.1, 10.3
 */
export declare const logErrorWithCode: (errorInfo: ErrorInfo, error: Error | null, requestContext?: {
    requestId?: string;
    functionName?: string;
    userId?: string;
    retryCount?: number;
}) => void;
/**
 * 成功ログの記録
 * 監査目的ですべての成功した回答送信をログに記録
 * 要件: 10.2
 */
export declare const logSuccess: (operation: string, context?: Record<string, unknown>) => void;
/**
 * タイムアウトログの記録
 * Lambda関数のタイムアウト発生時にログを記録
 * 要件: 10.3
 */
export declare const logTimeout: (functionName: string, requestDetails: Record<string, unknown>) => void;
/**
 * ユーザーフレンドリーなエラーレスポンス生成
 */
export declare const createErrorResponse: (errorInfo: ErrorInfo) => ErrorResponse;
/**
 * グローバルエラーハンドラー
 * Lambda関数で使用する統一的なエラーハンドリング
 * 要件: 10.1, 10.2, 10.3
 */
export declare const globalErrorHandler: (error: Error | ErrorCode, context: {
    requestId?: string;
    functionName?: string;
    userId?: string;
    retryCount?: number;
}) => Promise<{
    statusCode: number;
    headers: Record<string, string>;
    body: string;
}>;
/**
 * カスタムエラークラス
 * エラーコードを含むエラーを簡単に作成
 */
export declare class AppError extends Error {
    errorCode: ErrorCode;
    constructor(errorCode: ErrorCode, message?: string);
}
//# sourceMappingURL=errorHandler.d.ts.map