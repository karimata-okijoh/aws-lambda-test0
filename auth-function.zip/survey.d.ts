import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * メインハンドラー
 */
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=survey.d.ts.map