"use strict";
// ロギングユーティリティ
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = exports.Logger = exports.logWarn = exports.logInfo = exports.logError = exports.log = exports.LogLevel = void 0;
const security_1 = require("./security");
/**
 * ログレベル
 */
var LogLevel;
(function (LogLevel) {
    LogLevel["INFO"] = "INFO";
    LogLevel["WARN"] = "WARN";
    LogLevel["ERROR"] = "ERROR";
})(LogLevel || (exports.LogLevel = LogLevel = {}));
/**
 * ログ出力（CloudWatch Logsに記録）
 * 要件: 7.4 - パスワードの非露出
 */
const log = (entry) => {
    // セキュリティチェック（要件: 7.4）
    (0, security_1.validateLogSafety)(entry);
    // 機密情報をマスキング
    const sanitizedEntry = {
        ...entry,
        context: entry.context ? (0, security_1.maskSensitiveData)(entry.context) : undefined
    };
    // CloudWatch Logsに構造化ログとして出力
    console.log(JSON.stringify(sanitizedEntry));
};
exports.log = log;
/**
 * エラーログ出力
 */
const logError = (message, error, context) => {
    (0, exports.log)({
        timestamp: new Date().toISOString(),
        level: LogLevel.ERROR,
        message,
        context,
        stackTrace: error.stack
    });
};
exports.logError = logError;
/**
 * 情報ログ出力
 */
const logInfo = (message, context) => {
    (0, exports.log)({
        timestamp: new Date().toISOString(),
        level: LogLevel.INFO,
        message,
        context
    });
};
exports.logInfo = logInfo;
/**
 * 警告ログ出力
 */
const logWarn = (message, context) => {
    (0, exports.log)({
        timestamp: new Date().toISOString(),
        level: LogLevel.WARN,
        message,
        context
    });
};
exports.logWarn = logWarn;
/**
 * ロガークラス（オブジェクト指向スタイル）
 */
class Logger {
    info(message, context) {
        (0, exports.logInfo)(message, context);
    }
    warn(message, context) {
        (0, exports.logWarn)(message, context);
    }
    error(message, context) {
        (0, exports.log)({
            timestamp: new Date().toISOString(),
            level: LogLevel.ERROR,
            message,
            context,
            stackTrace: context?.stack
        });
    }
}
exports.Logger = Logger;
// デフォルトロガーインスタンス
exports.logger = new Logger();
//# sourceMappingURL=logger.js.map