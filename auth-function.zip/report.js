"use strict";
// レポートLambda関数
// タスク6.1: レポート生成機能の実装
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const jwt = __importStar(require("jsonwebtoken"));
const types_1 = require("../types");
const dynamodb_1 = require("../utils/dynamodb");
const constants_1 = require("../utils/constants");
const logger_1 = require("../utils/logger");
const security_1 = require("../utils/security");
/**
 * 環境変数の取得（セキュアバージョン）
 * 要件: 7.3
 */
const getEnvVar = (key) => {
    return (0, security_1.getSecretFromEnv)(key);
};
/**
 * JWTトークンの検証と管理者権限チェック
 * 要件: 6.1
 */
const verifyAdminToken = (token) => {
    try {
        const jwtSecret = getEnvVar('JWT_SECRET');
        const decoded = jwt.verify(token, jwtSecret);
        // 管理者権限チェック
        if (decoded.email !== constants_1.ADMIN_EMAIL || decoded.role !== 'admin') {
            return {
                valid: false,
                errorCode: types_1.ErrorCode.AUTH_005,
                message: 'この機能にアクセスする権限がありません'
            };
        }
        return { valid: true, payload: decoded };
    }
    catch (error) {
        if (error instanceof jwt.TokenExpiredError) {
            return {
                valid: false,
                errorCode: types_1.ErrorCode.AUTH_003,
                message: 'セッションが期限切れです。再度ログインしてください'
            };
        }
        return {
            valid: false,
            errorCode: types_1.ErrorCode.AUTH_004,
            message: '無効な認証情報です'
        };
    }
};
const calculateTimeSlotStats = (responses, totalResponses) => {
    const counts = {
        morning: 0,
        afternoon: 0,
        evening: 0
    };
    // 各ユーザーの回答を集計
    responses.forEach(response => {
        let userMorning = false;
        let userAfternoon = false;
        let userEvening = false;
        // 各日付の回答をチェック（1日でも使用していればカウント）
        Object.values(response.responses).forEach(dayResponse => {
            if (dayResponse.morning)
                userMorning = true;
            if (dayResponse.afternoon)
                userAfternoon = true;
            if (dayResponse.evening)
                userEvening = true;
        });
        if (userMorning)
            counts.morning++;
        if (userAfternoon)
            counts.afternoon++;
        if (userEvening)
            counts.evening++;
    });
    // パーセンテージの計算
    const calculatePercentage = (count) => {
        return totalResponses > 0 ? Math.round((count / totalResponses) * 100 * 100) / 100 : 0;
    };
    return {
        morning: {
            count: counts.morning,
            percentage: calculatePercentage(counts.morning)
        },
        afternoon: {
            count: counts.afternoon,
            percentage: calculatePercentage(counts.afternoon)
        },
        evening: {
            count: counts.evening,
            percentage: calculatePercentage(counts.evening)
        }
    };
};
/**
 * 利用パターンの分類
 * 要件: 6.4
 */
const calculateUsagePatterns = (responses) => {
    const patterns = {
        allTimeSlots: 0,
        twoTimeSlots: 0,
        oneTimeSlot: 0,
        noUsage: 0
    };
    responses.forEach(response => {
        let userMorning = false;
        let userAfternoon = false;
        let userEvening = false;
        // 各日付の回答をチェック（1日でも使用していればカウント）
        Object.values(response.responses).forEach(dayResponse => {
            if (dayResponse.morning)
                userMorning = true;
            if (dayResponse.afternoon)
                userAfternoon = true;
            if (dayResponse.evening)
                userEvening = true;
        });
        // 使用している時間帯の数をカウント
        const usedTimeSlots = [userMorning, userAfternoon, userEvening].filter(Boolean).length;
        switch (usedTimeSlots) {
            case 3:
                patterns.allTimeSlots++;
                break;
            case 2:
                patterns.twoTimeSlots++;
                break;
            case 1:
                patterns.oneTimeSlot++;
                break;
            case 0:
                patterns.noUsage++;
                break;
        }
    });
    return patterns;
};
/**
 * レポート生成Lambda関数ハンドラー
 * 要件: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6
 */
const handler = async (event) => {
    try {
        // クエリパラメータまたはヘッダーからトークンを取得
        const token = event.queryStringParameters?.token ||
            event.headers?.Authorization?.replace('Bearer ', '') ||
            event.headers?.authorization?.replace('Bearer ', '');
        if (!token) {
            return {
                statusCode: constants_1.HTTP_STATUS.UNAUTHORIZED,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: '認証トークンが必要です'
                })
            };
        }
        // JWTトークン検証と管理者権限チェック（要件: 6.1）
        const tokenValidation = verifyAdminToken(token);
        if (!tokenValidation.valid) {
            (0, logger_1.logInfo)('Admin token validation failed', {
                errorCode: tokenValidation.errorCode
            });
            return {
                statusCode: tokenValidation.errorCode === types_1.ErrorCode.AUTH_005
                    ? constants_1.HTTP_STATUS.FORBIDDEN
                    : constants_1.HTTP_STATUS.UNAUTHORIZED,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: tokenValidation.message
                })
            };
        }
        const { email } = tokenValidation.payload;
        // DynamoDBから全回答をスキャン（要件: 6.2）
        try {
            const allResponses = await (0, dynamodb_1.getAllResponses)();
            // 回答総数の計算（要件: 6.2）
            const totalResponses = allResponses.length;
            const targetCount = 25; // 対象人数（20-25名）
            const responseRate = targetCount > 0
                ? Math.round((totalResponses / targetCount) * 100 * 100) / 100
                : 0;
            // 時間帯別の集計計算（要件: 6.3）
            const timeSlotStats = calculateTimeSlotStats(allResponses, totalResponses);
            // 利用パターンの分類（要件: 6.4）
            const usagePatterns = calculateUsagePatterns(allResponses);
            // レポートデータの生成（要件: 6.5）
            const generatedAt = new Date().toISOString();
            (0, logger_1.logInfo)('Report generated successfully', {
                email,
                totalResponses,
                generatedAt
            });
            // レスポンス（要件: 6.6 - 10秒以内に結果を生成、7.4 - パスワードの非露出）
            const response = {
                success: true,
                data: {
                    totalResponses,
                    targetCount,
                    responseRate,
                    timeSlotStats,
                    usagePatterns,
                    generatedAt
                },
                message: 'レポートが正常に生成されました'
            };
            // レスポンスのセキュリティチェック
            const sanitizedResponseData = (0, security_1.sanitizeResponse)(response);
            return {
                statusCode: constants_1.HTTP_STATUS.OK,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify(sanitizedResponseData)
            };
        }
        catch (error) {
            (0, logger_1.logError)('Failed to generate report', error, {
                email,
                errorCode: types_1.ErrorCode.DB_003
            });
            return {
                statusCode: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: 'レポートの生成に失敗しました'
                })
            };
        }
    }
    catch (error) {
        (0, logger_1.logError)('Report generation error', error);
        return {
            statusCode: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                success: false,
                message: 'システムエラーが発生しました'
            })
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=report.js.map