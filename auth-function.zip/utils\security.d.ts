/**
 * オブジェクトから機密情報を検出
 * 要件: 7.4
 */
export declare const containsSensitiveData: (obj: unknown) => boolean;
/**
 * オブジェクトから機密情報をマスキング
 * ログ出力やAPIレスポンスに使用
 * 要件: 7.4
 */
export declare const maskSensitiveData: (obj: unknown) => unknown;
/**
 * ログ出力前に機密情報をチェック
 * パスワードが含まれている場合は警告を出力
 * 要件: 7.4
 */
export declare const validateLogSafety: (data: unknown) => void;
/**
 * APIレスポンスから機密情報を除去
 * 要件: 7.4
 */
export declare const sanitizeResponse: <T>(response: T) => T;
/**
 * 環境変数から機密情報を安全に取得
 * 要件: 7.3
 */
export declare const getSecretFromEnv: (key: string) => string;
export declare const getSecretFromSSM: (parameterName: string) => Promise<string>;
/**
 * パスワードの強度チェック（オプション）
 */
export declare const isStrongPassword: (password: string) => boolean;
//# sourceMappingURL=security.d.ts.map