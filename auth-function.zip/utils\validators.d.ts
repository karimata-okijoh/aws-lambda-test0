/**
 * メールアドレスのドメイン検証
 */
export declare const isValidDomain: (email: string) => boolean;
/**
 * 日付形式の検証（YYYY-MM-DD）
 */
export declare const isValidDateFormat: (date: string) => boolean;
/**
 * 入力データのサニタイズ
 * インジェクション攻撃を防ぐために危険な文字列をエスケープ
 * 要件: 7.5
 */
export declare const sanitizeInput: (input: string) => string;
/**
 * メールアドレスのサニタイズ
 * メールアドレス専用のサニタイズ処理
 * 要件: 7.5
 */
export declare const sanitizeEmail: (email: string) => string;
/**
 * アンケート期間内かチェック
 */
export declare const isWithinSurveyPeriod: (date: Date, startDate: string, endDate: string) => boolean;
//# sourceMappingURL=validators.d.ts.map