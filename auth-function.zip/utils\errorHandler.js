"use strict";
// グローバルエラーハンドラー
// タスク7.1: エラー分類ロジック、エラーログフォーマット、CloudWatch Logsへのログ記録、ユーザーフレンドリーなエラーレスポンス生成
// 要件: 10.1, 10.2, 10.3
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppError = exports.globalErrorHandler = exports.createErrorResponse = exports.logTimeout = exports.logSuccess = exports.logErrorWithCode = exports.classifyError = exports.ErrorType = void 0;
const types_1 = require("../types");
const logger_1 = require("./logger");
const constants_1 = require("./constants");
/**
 * エラータイプ
 */
var ErrorType;
(function (ErrorType) {
    ErrorType["AuthenticationError"] = "AuthenticationError";
    ErrorType["ValidationError"] = "ValidationError";
    ErrorType["DataStoreError"] = "DataStoreError";
    ErrorType["PeriodConstraintError"] = "PeriodConstraintError";
    ErrorType["SystemError"] = "SystemError";
})(ErrorType || (exports.ErrorType = ErrorType = {}));
/**
 * エラーコードとHTTPステータス、ユーザーメッセージのマッピング
 */
const ERROR_MAPPINGS = {
    // 認証エラー (AUTH_001 - AUTH_005)
    [types_1.ErrorCode.AUTH_001]: {
        type: ErrorType.AuthenticationError,
        httpStatus: constants_1.HTTP_STATUS.FORBIDDEN,
        userMessage: 'このアンケートは社内メンバー専用です'
    },
    [types_1.ErrorCode.AUTH_002]: {
        type: ErrorType.AuthenticationError,
        httpStatus: constants_1.HTTP_STATUS.UNAUTHORIZED,
        userMessage: 'メールアドレスまたはパスワードが正しくありません'
    },
    [types_1.ErrorCode.AUTH_003]: {
        type: ErrorType.AuthenticationError,
        httpStatus: constants_1.HTTP_STATUS.UNAUTHORIZED,
        userMessage: 'セッションが期限切れです。再度ログインしてください'
    },
    [types_1.ErrorCode.AUTH_004]: {
        type: ErrorType.AuthenticationError,
        httpStatus: constants_1.HTTP_STATUS.UNAUTHORIZED,
        userMessage: '無効な認証情報です'
    },
    [types_1.ErrorCode.AUTH_005]: {
        type: ErrorType.AuthenticationError,
        httpStatus: constants_1.HTTP_STATUS.FORBIDDEN,
        userMessage: 'この機能にアクセスする権限がありません'
    },
    // 入力検証エラー (VAL_001 - VAL_003)
    [types_1.ErrorCode.VAL_001]: {
        type: ErrorType.ValidationError,
        httpStatus: constants_1.HTTP_STATUS.BAD_REQUEST,
        userMessage: 'すべての時間帯について回答を選択してください'
    },
    [types_1.ErrorCode.VAL_002]: {
        type: ErrorType.ValidationError,
        httpStatus: constants_1.HTTP_STATUS.BAD_REQUEST,
        userMessage: '入力形式が正しくありません'
    },
    [types_1.ErrorCode.VAL_003]: {
        type: ErrorType.ValidationError,
        httpStatus: constants_1.HTTP_STATUS.BAD_REQUEST,
        userMessage: '入力内容に使用できない文字が含まれています'
    },
    // データストアエラー (DB_001 - DB_004)
    [types_1.ErrorCode.DB_001]: {
        type: ErrorType.DataStoreError,
        httpStatus: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
        userMessage: '一時的なエラーが発生しました。しばらくしてから再度お試しください'
    },
    [types_1.ErrorCode.DB_002]: {
        type: ErrorType.DataStoreError,
        httpStatus: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
        userMessage: '回答の保存に失敗しました。再度お試しください'
    },
    [types_1.ErrorCode.DB_003]: {
        type: ErrorType.DataStoreError,
        httpStatus: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
        userMessage: 'データの取得に失敗しました'
    },
    [types_1.ErrorCode.DB_004]: {
        type: ErrorType.DataStoreError,
        httpStatus: constants_1.HTTP_STATUS.GATEWAY_TIMEOUT,
        userMessage: '処理がタイムアウトしました。再度お試しください'
    },
    // 期間制約エラー (PERIOD_001 - PERIOD_002)
    [types_1.ErrorCode.PERIOD_001]: {
        type: ErrorType.PeriodConstraintError,
        httpStatus: constants_1.HTTP_STATUS.FORBIDDEN,
        userMessage: 'アンケートはまだ開始されていません（開始日: 2026年3月15日）'
    },
    [types_1.ErrorCode.PERIOD_002]: {
        type: ErrorType.PeriodConstraintError,
        httpStatus: constants_1.HTTP_STATUS.FORBIDDEN,
        userMessage: 'アンケートは終了しました（終了日: 2026年6月27日）'
    },
    // システムエラー (SYS_001 - SYS_003)
    [types_1.ErrorCode.SYS_001]: {
        type: ErrorType.SystemError,
        httpStatus: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
        userMessage: 'システムエラーが発生しました'
    },
    [types_1.ErrorCode.SYS_002]: {
        type: ErrorType.SystemError,
        httpStatus: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
        userMessage: 'システムエラーが発生しました'
    },
    [types_1.ErrorCode.SYS_003]: {
        type: ErrorType.SystemError,
        httpStatus: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
        userMessage: '予期しないエラーが発生しました'
    }
};
/**
 * エラー分類ロジック
 * エラーオブジェクトまたはエラーコードからエラー情報を生成
 * 要件: 10.1
 */
const classifyError = (error, context) => {
    // ErrorCodeが直接渡された場合
    if (typeof error === 'string' && error in ERROR_MAPPINGS) {
        const mapping = ERROR_MAPPINGS[error];
        return {
            code: error,
            type: mapping.type,
            httpStatus: mapping.httpStatus,
            userMessage: mapping.userMessage,
            context
        };
    }
    // Errorオブジェクトの場合、エラーメッセージからエラーコードを抽出
    if (error instanceof Error) {
        // エラーメッセージにエラーコードが含まれている場合
        const errorCodeMatch = error.message.match(/^(AUTH|VAL|DB|PERIOD|SYS)_\d{3}/);
        if (errorCodeMatch) {
            const errorCode = errorCodeMatch[0];
            if (errorCode in ERROR_MAPPINGS) {
                const mapping = ERROR_MAPPINGS[errorCode];
                return {
                    code: errorCode,
                    type: mapping.type,
                    httpStatus: mapping.httpStatus,
                    userMessage: mapping.userMessage,
                    context
                };
            }
        }
        // エラー名からエラータイプを推測
        if (error.name === 'ValidationError') {
            return {
                code: types_1.ErrorCode.VAL_002,
                type: ErrorType.ValidationError,
                httpStatus: constants_1.HTTP_STATUS.BAD_REQUEST,
                userMessage: '入力形式が正しくありません',
                context
            };
        }
        if (error.name === 'TimeoutError') {
            return {
                code: types_1.ErrorCode.DB_004,
                type: ErrorType.DataStoreError,
                httpStatus: constants_1.HTTP_STATUS.GATEWAY_TIMEOUT,
                userMessage: '処理がタイムアウトしました。再度お試しください',
                context
            };
        }
        // DynamoDBエラー
        if (error.name.includes('DynamoDB') || error.message.includes('DynamoDB')) {
            return {
                code: types_1.ErrorCode.DB_001,
                type: ErrorType.DataStoreError,
                httpStatus: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
                userMessage: '一時的なエラーが発生しました。しばらくしてから再度お試しください',
                context
            };
        }
    }
    // デフォルト: 予期しないエラー
    return {
        code: types_1.ErrorCode.SYS_003,
        type: ErrorType.SystemError,
        httpStatus: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
        userMessage: '予期しないエラーが発生しました',
        context
    };
};
exports.classifyError = classifyError;
/**
 * エラーログの記録
 * CloudWatch Logsに構造化ログとして記録
 * 要件: 10.1, 10.3
 */
const logErrorWithCode = (errorInfo, error, requestContext) => {
    (0, logger_1.log)({
        timestamp: new Date().toISOString(),
        level: logger_1.LogLevel.ERROR,
        errorCode: errorInfo.code,
        message: error?.message || errorInfo.userMessage,
        context: {
            errorType: errorInfo.type,
            ...requestContext,
            ...errorInfo.context
        },
        stackTrace: error?.stack
    });
};
exports.logErrorWithCode = logErrorWithCode;
/**
 * 成功ログの記録
 * 監査目的ですべての成功した回答送信をログに記録
 * 要件: 10.2
 */
const logSuccess = (operation, context) => {
    (0, logger_1.log)({
        timestamp: new Date().toISOString(),
        level: logger_1.LogLevel.INFO,
        message: `Operation successful: ${operation}`,
        context
    });
};
exports.logSuccess = logSuccess;
/**
 * タイムアウトログの記録
 * Lambda関数のタイムアウト発生時にログを記録
 * 要件: 10.3
 */
const logTimeout = (functionName, requestDetails) => {
    (0, logger_1.log)({
        timestamp: new Date().toISOString(),
        level: logger_1.LogLevel.ERROR,
        errorCode: types_1.ErrorCode.DB_004,
        message: `Lambda function timeout: ${functionName}`,
        context: {
            errorType: ErrorType.SystemError,
            functionName,
            ...requestDetails
        }
    });
};
exports.logTimeout = logTimeout;
/**
 * ユーザーフレンドリーなエラーレスポンス生成
 */
const createErrorResponse = (errorInfo) => {
    return {
        success: false,
        errorCode: errorInfo.code,
        message: errorInfo.userMessage,
        timestamp: new Date().toISOString()
    };
};
exports.createErrorResponse = createErrorResponse;
/**
 * グローバルエラーハンドラー
 * Lambda関数で使用する統一的なエラーハンドリング
 * 要件: 10.1, 10.2, 10.3
 */
const globalErrorHandler = async (error, context) => {
    // エラー分類
    const errorInfo = (0, exports.classifyError)(error, context);
    // ログ記録
    (0, exports.logErrorWithCode)(errorInfo, error instanceof Error ? error : null, context);
    // ユーザーレスポンス生成
    const errorResponse = (0, exports.createErrorResponse)(errorInfo);
    return {
        statusCode: errorInfo.httpStatus,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify(errorResponse)
    };
};
exports.globalErrorHandler = globalErrorHandler;
/**
 * カスタムエラークラス
 * エラーコードを含むエラーを簡単に作成
 */
class AppError extends Error {
    constructor(errorCode, message) {
        super(message || `${errorCode}: ${ERROR_MAPPINGS[errorCode]?.userMessage || 'Unknown error'}`);
        this.errorCode = errorCode;
        this.name = 'AppError';
    }
}
exports.AppError = AppError;
//# sourceMappingURL=errorHandler.js.map