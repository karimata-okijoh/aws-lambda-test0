/**
 * アンケート期間
 */
export declare const SURVEY_PERIOD: {
    readonly START_DATE: "2026-03-15";
    readonly END_DATE: "2026-06-27";
};
/**
 * 管理者メールアドレス
 */
export declare const ADMIN_EMAIL = "karimata@okijoh.co.jp";
/**
 * 許可されたドメイン
 */
export declare const ALLOWED_DOMAIN = "@okijoh.co.jp";
/**
 * JWTトークンの有効期限（24時間）
 */
export declare const JWT_EXPIRATION: number;
/**
 * DynamoDBリトライ設定
 */
export declare const RETRY_CONFIG: {
    readonly MAX_RETRIES: 3;
    readonly RETRY_DELAY_MS: 1000;
};
/**
 * 時間帯の定義
 */
export declare const TIME_SLOTS: {
    readonly MORNING: "morning";
    readonly AFTERNOON: "afternoon";
    readonly EVENING: "evening";
};
/**
 * HTTPステータスコード
 */
export declare const HTTP_STATUS: {
    readonly OK: 200;
    readonly BAD_REQUEST: 400;
    readonly UNAUTHORIZED: 401;
    readonly FORBIDDEN: 403;
    readonly NOT_FOUND: 404;
    readonly INTERNAL_SERVER_ERROR: 500;
    readonly NOT_IMPLEMENTED: 501;
    readonly GATEWAY_TIMEOUT: 504;
};
//# sourceMappingURL=constants.d.ts.map