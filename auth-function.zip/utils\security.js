"use strict";
// セキュリティユーティリティ
// タスク7.2: パスワードの非露出チェック、機密情報のマスキング
// 要件: 7.4
Object.defineProperty(exports, "__esModule", { value: true });
exports.isStrongPassword = exports.getSecretFromSSM = exports.getSecretFromEnv = exports.sanitizeResponse = exports.validateLogSafety = exports.maskSensitiveData = exports.containsSensitiveData = void 0;
const client_ssm_1 = require("@aws-sdk/client-ssm");
/**
 * 機密情報のパターン
 */
const SENSITIVE_PATTERNS = [
    /password/gi,
    /passwd/gi,
    /pwd/gi,
    /secret/gi,
    /api[_-]?key/gi,
    /access[_-]?key/gi,
    /private[_-]?key/gi
];
/**
 * 機密情報を含むキーのリスト
 */
const SENSITIVE_KEYS = [
    'password',
    'passwd',
    'pwd',
    'secret',
    'apiKey',
    'api_key',
    'accessKey',
    'access_key',
    'privateKey',
    'private_key',
    'COMMON_PASSWORD',
    'ADMIN_PASSWORD'
];
/**
 * オブジェクトから機密情報を検出
 * 要件: 7.4
 */
const containsSensitiveData = (obj) => {
    if (typeof obj !== 'object' || obj === null) {
        return false;
    }
    const checkObject = (o) => {
        for (const key in o) {
            // キー名が機密情報を示す場合
            if (SENSITIVE_KEYS.some(sensitiveKey => key.toLowerCase().includes(sensitiveKey.toLowerCase()))) {
                return true;
            }
            // 値が文字列の場合、パターンマッチング
            if (typeof o[key] === 'string') {
                for (const pattern of SENSITIVE_PATTERNS) {
                    if (pattern.test(key)) {
                        return true;
                    }
                }
            }
            // ネストされたオブジェクトを再帰的にチェック
            if (typeof o[key] === 'object' && o[key] !== null) {
                if (checkObject(o[key])) {
                    return true;
                }
            }
        }
        return false;
    };
    return checkObject(obj);
};
exports.containsSensitiveData = containsSensitiveData;
/**
 * オブジェクトから機密情報をマスキング
 * ログ出力やAPIレスポンスに使用
 * 要件: 7.4
 */
const maskSensitiveData = (obj) => {
    if (typeof obj !== 'object' || obj === null) {
        return obj;
    }
    if (Array.isArray(obj)) {
        return obj.map(item => (0, exports.maskSensitiveData)(item));
    }
    const masked = {};
    const original = obj;
    for (const key in original) {
        // キー名が機密情報を示す場合、値をマスキング
        const isSensitiveKey = SENSITIVE_KEYS.some(sensitiveKey => key.toLowerCase().includes(sensitiveKey.toLowerCase()));
        if (isSensitiveKey) {
            masked[key] = '***MASKED***';
        }
        else if (typeof original[key] === 'object' && original[key] !== null) {
            // ネストされたオブジェクトを再帰的にマスキング
            masked[key] = (0, exports.maskSensitiveData)(original[key]);
        }
        else {
            masked[key] = original[key];
        }
    }
    return masked;
};
exports.maskSensitiveData = maskSensitiveData;
/**
 * ログ出力前に機密情報をチェック
 * パスワードが含まれている場合は警告を出力
 * 要件: 7.4
 */
const validateLogSafety = (data) => {
    if ((0, exports.containsSensitiveData)(data)) {
        console.warn('[SECURITY WARNING] Attempted to log sensitive data. Data has been masked.');
    }
};
exports.validateLogSafety = validateLogSafety;
/**
 * APIレスポンスから機密情報を除去
 * 要件: 7.4
 */
const sanitizeResponse = (response) => {
    // 機密情報が含まれているかチェック
    if ((0, exports.containsSensitiveData)(response)) {
        console.warn('[SECURITY WARNING] Response contains sensitive data. Masking applied.');
        return (0, exports.maskSensitiveData)(response);
    }
    return response;
};
exports.sanitizeResponse = sanitizeResponse;
/**
 * 環境変数から機密情報を安全に取得
 * 要件: 7.3
 */
const getSecretFromEnv = (key) => {
    const value = process.env[key];
    if (!value) {
        throw new Error(`Environment variable ${key} is not set`);
    }
    return value;
};
exports.getSecretFromEnv = getSecretFromEnv;
/**
 * SSMパラメータストアから機密情報を取得
 * 要件: 7.3
 */
const ssmClient = new client_ssm_1.SSMClient({ region: process.env.AWS_REGION || 'ap-northeast-1' });
const parameterCache = {};
const CACHE_TTL = 5 * 60 * 1000; // 5分
const getSecretFromSSM = async (parameterName) => {
    // キャッシュチェック
    const cached = parameterCache[parameterName];
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
        return cached.value;
    }
    try {
        const command = new client_ssm_1.GetParameterCommand({
            Name: parameterName,
            WithDecryption: true
        });
        const response = await ssmClient.send(command);
        if (!response.Parameter?.Value) {
            throw new Error(`SSM parameter ${parameterName} not found`);
        }
        // キャッシュに保存
        parameterCache[parameterName] = {
            value: response.Parameter.Value,
            timestamp: Date.now()
        };
        return response.Parameter.Value;
    }
    catch (error) {
        console.error(`Failed to get SSM parameter ${parameterName}:`, error);
        throw new Error(`Failed to retrieve ${parameterName} from SSM`);
    }
};
exports.getSecretFromSSM = getSecretFromSSM;
/**
 * パスワードの強度チェック（オプション）
 */
const isStrongPassword = (password) => {
    // 最低8文字
    if (password.length < 8) {
        return false;
    }
    // 大文字、小文字、数字、特殊文字を含む
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const hasSpecialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password);
    return hasUpperCase && hasLowerCase && hasNumber && hasSpecialChar;
};
exports.isStrongPassword = isStrongPassword;
//# sourceMappingURL=security.js.map