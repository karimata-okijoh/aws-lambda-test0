import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * 認証Lambda関数ハンドラー
 * 要件: 1.2, 1.3, 1.4, 1.6, 1.7, 1.8, 7.3
 */
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=auth.d.ts.map