"use strict";
// アンケートLambda関数
// タスク4.1: アンケート回答送信機能の実装
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const jwt = __importStar(require("jsonwebtoken"));
const types_1 = require("../types");
const dynamodb_1 = require("../utils/dynamodb");
const validators_1 = require("../utils/validators");
const constants_1 = require("../utils/constants");
const logger_1 = require("../utils/logger");
const security_1 = require("../utils/security");
/**
 * 環境変数の取得（セキュアバージョン）
 * 要件: 7.3
 */
const getEnvVar = (key) => {
    return (0, security_1.getSecretFromEnv)(key);
};
/**
 * JWTトークンの検証
 * 要件: 2.1
 */
const verifyToken = (token) => {
    try {
        const jwtSecret = getEnvVar('JWT_SECRET');
        const decoded = jwt.verify(token, jwtSecret);
        return { valid: true, payload: decoded };
    }
    catch (error) {
        if (error instanceof jwt.TokenExpiredError) {
            return {
                valid: false,
                errorCode: types_1.ErrorCode.AUTH_003,
                message: 'セッションが期限切れです。再度ログインしてください'
            };
        }
        return {
            valid: false,
            errorCode: types_1.ErrorCode.AUTH_004,
            message: '無効な認証情報です'
        };
    }
};
/**
 * アンケート期間のチェック
 * 要件: 8.1, 8.2, 8.3, 8.4
 */
const checkSurveyPeriod = (currentDate) => {
    const startDate = new Date(constants_1.SURVEY_PERIOD.START_DATE);
    const endDate = new Date(constants_1.SURVEY_PERIOD.END_DATE);
    // 開始前のチェック（要件: 8.2）
    if (currentDate < startDate) {
        return {
            valid: false,
            errorCode: types_1.ErrorCode.PERIOD_001,
            message: `アンケートはまだ開始されていません（開始日: ${constants_1.SURVEY_PERIOD.START_DATE}）`
        };
    }
    // 終了後のチェック（要件: 8.3）
    if (currentDate > endDate) {
        return {
            valid: false,
            errorCode: types_1.ErrorCode.PERIOD_002,
            message: `アンケートは終了しました（終了日: ${constants_1.SURVEY_PERIOD.END_DATE}）`
        };
    }
    // 期間内（要件: 8.4）
    return { valid: true };
};
/**
 * 入力データの検証
 * 要件: 2.4, 2.7, 7.5
 */
const validateSurveyData = (responses) => {
    // 回答が空でないかチェック
    if (!responses || Object.keys(responses).length === 0) {
        return {
            valid: false,
            errorCode: types_1.ErrorCode.VAL_001,
            message: '回答データが必要です'
        };
    }
    // 各日付の検証
    for (const [date, timeSlots] of Object.entries(responses)) {
        // 日付形式の検証とサニタイズ（要件: 7.5）
        try {
            const sanitizedDate = (0, validators_1.sanitizeInput)(date);
            if (!(0, validators_1.isValidDateFormat)(sanitizedDate)) {
                return {
                    valid: false,
                    errorCode: types_1.ErrorCode.VAL_002,
                    message: `不正な日付形式です: ${date}`
                };
            }
        }
        catch (error) {
            return {
                valid: false,
                errorCode: types_1.ErrorCode.VAL_003,
                message: `日付に使用できない文字が含まれています: ${date}`
            };
        }
        // 時間帯の値の検証
        if (typeof timeSlots.morning !== 'boolean' ||
            typeof timeSlots.afternoon !== 'boolean' ||
            typeof timeSlots.evening !== 'boolean') {
            return {
                valid: false,
                errorCode: types_1.ErrorCode.VAL_002,
                message: `時間帯の値が不正です: ${date}`
            };
        }
    }
    return { valid: true };
};
/**
 * アンケート回答送信ハンドラー
 * 要件: 2.8, 2.9, 8.1, 8.2, 8.3, 8.4
 */
const handleSubmitSurvey = async (event) => {
    try {
        // リクエストボディのパース
        if (!event.body) {
            return {
                statusCode: constants_1.HTTP_STATUS.BAD_REQUEST,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: 'リクエストボディが必要です'
                })
            };
        }
        const request = JSON.parse(event.body);
        const { token, responses } = request;
        // トークン検証
        if (!token) {
            return {
                statusCode: constants_1.HTTP_STATUS.UNAUTHORIZED,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: '認証トークンが必要です'
                })
            };
        }
        const tokenValidation = verifyToken(token);
        if (!tokenValidation.valid) {
            return {
                statusCode: constants_1.HTTP_STATUS.UNAUTHORIZED,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: tokenValidation.message
                })
            };
        }
        const { email } = tokenValidation.payload;
        // アンケート期間のチェック（要件: 8.1, 8.2, 8.3, 8.4）
        const currentDate = new Date();
        const periodCheck = checkSurveyPeriod(currentDate);
        if (!periodCheck.valid) {
            (0, logger_1.logInfo)('Survey period check failed', {
                email,
                currentDate: currentDate.toISOString(),
                errorCode: periodCheck.errorCode
            });
            return {
                statusCode: constants_1.HTTP_STATUS.FORBIDDEN,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: periodCheck.message
                })
            };
        }
        // 入力データの検証
        const dataValidation = validateSurveyData(responses);
        if (!dataValidation.valid) {
            (0, logger_1.logInfo)('Survey data validation failed', {
                email,
                errorCode: dataValidation.errorCode
            });
            return {
                statusCode: constants_1.HTTP_STATUS.BAD_REQUEST,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: dataValidation.message
                })
            };
        }
        // DynamoDBへの保存/更新（要件: 2.8, 2.9）
        try {
            await (0, dynamodb_1.saveResponse)(email, responses);
            // 保存後のデータを取得
            const savedData = await (0, dynamodb_1.getResponse)(email);
            (0, logger_1.logInfo)('Survey response saved successfully', {
                email,
                dateCount: Object.keys(responses).length
            });
            // 成功レスポンス（要件: 7.4）
            const response = {
                success: true,
                data: savedData || undefined,
                message: '回答が正常に保存されました'
            };
            // レスポンスのセキュリティチェック
            const sanitizedResponseData = (0, security_1.sanitizeResponse)(response);
            return {
                statusCode: constants_1.HTTP_STATUS.OK,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify(sanitizedResponseData)
            };
        }
        catch (error) {
            (0, logger_1.logError)('Failed to save survey response', error, {
                email,
                errorCode: types_1.ErrorCode.DB_002
            });
            return {
                statusCode: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: '回答の保存に失敗しました。再度お試しください'
                })
            };
        }
    }
    catch (error) {
        (0, logger_1.logError)('Survey submission error', error);
        return {
            statusCode: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                success: false,
                message: 'システムエラーが発生しました'
            })
        };
    }
};
/**
 * 週の開始日（月曜日）を計算
 * 要件: 5.1
 */
const getWeekStart = (date) => {
    const d = new Date(date);
    const day = d.getDay(); // 0 (日曜) から 6 (土曜)
    const diff = day === 0 ? -6 : 1 - day; // 月曜日を週の開始とする
    d.setDate(d.getDate() + diff);
    // YYYY-MM-DD形式で返す
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const dayOfMonth = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${dayOfMonth}`;
};
/**
 * システム日付に基づいて表示すべき週の開始日を計算
 * 要件: 5.1, 5.2, 5.3
 */
const getCurrentWeekStart = () => {
    const currentDate = new Date();
    const startDate = new Date(constants_1.SURVEY_PERIOD.START_DATE);
    const endDate = new Date(constants_1.SURVEY_PERIOD.END_DATE);
    // システム日付がアンケート期間より前の場合（要件: 5.2）
    if (currentDate < startDate) {
        return getWeekStart(startDate);
    }
    // システム日付がアンケート期間より後の場合（要件: 5.3）
    if (currentDate > endDate) {
        return getWeekStart(endDate);
    }
    // システム日付がアンケート期間内の場合（要件: 5.1）
    return getWeekStart(currentDate);
};
/**
 * アンケート回答取得ハンドラー
 * 要件: 4.1, 4.2, 5.1
 */
const handleGetSurvey = async (event) => {
    try {
        // クエリパラメータからトークンを取得
        const token = event.queryStringParameters?.token;
        if (!token) {
            return {
                statusCode: constants_1.HTTP_STATUS.UNAUTHORIZED,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: '認証トークンが必要です'
                })
            };
        }
        // JWTトークン検証（要件: 4.1）
        const tokenValidation = verifyToken(token);
        if (!tokenValidation.valid) {
            return {
                statusCode: constants_1.HTTP_STATUS.UNAUTHORIZED,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: tokenValidation.message
                })
            };
        }
        const { email } = tokenValidation.payload;
        // システム日付の週の開始日を計算（要件: 5.1）
        const currentWeekStart = getCurrentWeekStart();
        // メールアドレスをキーとした既存回答の取得（要件: 4.1）
        try {
            const existingResponse = await (0, dynamodb_1.getResponse)(email);
            (0, logger_1.logInfo)('Survey response retrieved successfully', {
                email,
                hasData: !!existingResponse,
                currentWeekStart
            });
            // 既存回答の返却（存在しない場合は空）（要件: 4.2, 7.4）
            const response = {
                success: true,
                data: existingResponse || undefined,
                currentWeekStart,
                message: existingResponse ? '既存の回答を取得しました' : '回答データがありません'
            };
            // レスポンスのセキュリティチェック
            const sanitizedResponseData = (0, security_1.sanitizeResponse)(response);
            return {
                statusCode: constants_1.HTTP_STATUS.OK,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify(sanitizedResponseData)
            };
        }
        catch (error) {
            (0, logger_1.logError)('Failed to retrieve survey response', error, {
                email,
                errorCode: types_1.ErrorCode.DB_003
            });
            return {
                statusCode: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: 'データの取得に失敗しました'
                })
            };
        }
    }
    catch (error) {
        (0, logger_1.logError)('Survey retrieval error', error);
        return {
            statusCode: constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                success: false,
                message: 'システムエラーが発生しました'
            })
        };
    }
};
/**
 * メインハンドラー
 */
const handler = async (event) => {
    const method = event.httpMethod;
    if (method === 'POST') {
        return handleSubmitSurvey(event);
    }
    else if (method === 'GET') {
        return handleGetSurvey(event);
    }
    else {
        return {
            statusCode: constants_1.HTTP_STATUS.BAD_REQUEST,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                success: false,
                message: 'サポートされていないHTTPメソッドです'
            })
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=survey.js.map