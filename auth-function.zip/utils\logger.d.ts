/**
 * ログレベル
 */
export declare enum LogLevel {
    INFO = "INFO",
    WARN = "WARN",
    ERROR = "ERROR"
}
/**
 * ログエントリ
 */
export interface LogEntry {
    timestamp: string;
    level: LogLevel;
    message: string;
    context?: Record<string, unknown>;
    errorCode?: string;
    stackTrace?: string;
}
/**
 * ログ出力（CloudWatch Logsに記録）
 * 要件: 7.4 - パスワードの非露出
 */
export declare const log: (entry: LogEntry) => void;
/**
 * エラーログ出力
 */
export declare const logError: (message: string, error: Error, context?: Record<string, unknown>) => void;
/**
 * 情報ログ出力
 */
export declare const logInfo: (message: string, context?: Record<string, unknown>) => void;
/**
 * 警告ログ出力
 */
export declare const logWarn: (message: string, context?: Record<string, unknown>) => void;
/**
 * ロガークラス（オブジェクト指向スタイル）
 */
export declare class Logger {
    info(message: string, context?: Record<string, unknown>): void;
    warn(message: string, context?: Record<string, unknown>): void;
    error(message: string, context?: Record<string, unknown> & {
        error?: string;
        stack?: string;
    }): void;
}
export declare const logger: Logger;
//# sourceMappingURL=logger.d.ts.map