/**
 * ログインリクエスト
 */
export interface LoginRequest {
    email: string;
    password: string;
}
/**
 * ログインレスポンス
 */
export interface LoginResponse {
    success: boolean;
    token?: string;
    role: 'user' | 'admin';
    message?: string;
}
/**
 * アンケート回答送信リクエスト
 */
export interface SubmitSurveyRequest {
    token: string;
    responses: {
        [date: string]: {
            morning: boolean;
            afternoon: boolean;
            evening: boolean;
        };
    };
}
/**
 * アンケート回答取得リクエスト
 */
export interface GetSurveyRequest {
    token: string;
    startDate?: string;
    endDate?: string;
}
/**
 * アンケートレスポンス
 */
export interface SurveyResponse {
    success: boolean;
    data?: {
        email: string;
        responses: {
            [date: string]: {
                morning: boolean;
                afternoon: boolean;
                evening: boolean;
            };
        };
        createdAt: string;
        updatedAt: string;
    };
    currentWeekStart?: string;
    message?: string;
}
/**
 * レポート生成リクエスト
 */
export interface GenerateReportRequest {
    token: string;
}
/**
 * レポートレスポンス
 */
export interface ReportResponse {
    success: boolean;
    data?: {
        totalResponses: number;
        targetCount: number;
        responseRate: number;
        timeSlotStats: {
            morning: {
                count: number;
                percentage: number;
            };
            afternoon: {
                count: number;
                percentage: number;
            };
            evening: {
                count: number;
                percentage: number;
            };
        };
        usagePatterns: {
            allTimeSlots: number;
            twoTimeSlots: number;
            oneTimeSlot: number;
            noUsage: number;
        };
        generatedAt: string;
    };
    message?: string;
}
/**
 * JWTペイロード
 */
export interface JWTPayload {
    email: string;
    role: 'user' | 'admin';
    iat: number;
    exp: number;
}
/**
 * DynamoDB - セッションテーブル
 */
export interface SessionItem {
    sessionId: string;
    email: string;
    role: 'user' | 'admin';
    createdAt: number;
    expiresAt: number;
}
/**
 * DynamoDB - 回答テーブル
 */
export interface ResponseItem {
    email: string;
    responses: {
        [date: string]: {
            morning: boolean;
            afternoon: boolean;
            evening: boolean;
        };
    };
    createdAt: string;
    updatedAt: string;
}
/**
 * エラーコード
 */
export declare enum ErrorCode {
    AUTH_001 = "AUTH_001",// 無効なドメイン
    AUTH_002 = "AUTH_002",// パスワード不一致
    AUTH_003 = "AUTH_003",// トークン期限切れ
    AUTH_004 = "AUTH_004",// トークン不正
    AUTH_005 = "AUTH_005",// 権限不足
    VAL_001 = "VAL_001",// 必須フィールド未入力
    VAL_002 = "VAL_002",// 不正な形式
    VAL_003 = "VAL_003",// 危険な文字列検出
    DB_001 = "DB_001",// 接続エラー
    DB_002 = "DB_002",// 保存失敗
    DB_003 = "DB_003",// 取得失敗
    DB_004 = "DB_004",// タイムアウト
    PERIOD_001 = "PERIOD_001",// 開始前アクセス
    PERIOD_002 = "PERIOD_002",// 終了後アクセス
    SYS_001 = "SYS_001",// Lambda関数エラー
    SYS_002 = "SYS_002",// メモリ不足
    SYS_003 = "SYS_003"
}
/**
 * エラーレスポンス
 */
export interface ErrorResponse {
    success: false;
    errorCode: ErrorCode;
    message: string;
    timestamp: string;
}
/**
 * アンケート期間設定
 */
export interface SurveyPeriod {
    startDate: string;
    endDate: string;
}
/**
 * 環境変数
 */
export interface EnvironmentVariables {
    COMMON_PASSWORD: string;
    ADMIN_PASSWORD: string;
    JWT_SECRET: string;
    SURVEY_START_DATE: string;
    SURVEY_END_DATE: string;
    DYNAMODB_SESSIONS_TABLE: string;
    DYNAMODB_RESPONSES_TABLE: string;
}
//# sourceMappingURL=index.d.ts.map