"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.putItem = putItem;
exports.getItem = getItem;
exports.updateItem = updateItem;
exports.scanTable = scanTable;
exports.saveSession = saveSession;
exports.getSession = getSession;
exports.saveResponse = saveResponse;
exports.getResponse = getResponse;
exports.getAllResponses = getAllResponses;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const logger_1 = require("./logger");
// DynamoDBクライアントの初期化
const client = new client_dynamodb_1.DynamoDBClient({
    region: process.env.AWS_REGION || 'ap-northeast-1',
});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client, {
    marshallOptions: {
        removeUndefinedValues: true,
        convertEmptyValues: false,
    },
});
// リトライ設定
const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 100;
/**
 * 指数バックオフでリトライを実行するヘルパー関数
 */
async function retryWithBackoff(operation, operationName, retries = MAX_RETRIES) {
    let lastError;
    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            const result = await operation();
            if (attempt > 1) {
                logger_1.logger.info(`${operationName} succeeded on attempt ${attempt}`);
            }
            return result;
        }
        catch (error) {
            lastError = error;
            logger_1.logger.warn(`${operationName} failed on attempt ${attempt}/${retries}`, {
                error: lastError.message,
                attempt,
            });
            if (attempt < retries) {
                // 指数バックオフ: 100ms, 200ms, 400ms
                const delay = RETRY_DELAY_MS * Math.pow(2, attempt - 1);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }
    // すべてのリトライが失敗した場合
    logger_1.logger.error(`${operationName} failed after ${retries} attempts`, {
        error: lastError?.message,
        stack: lastError?.stack,
    });
    throw new Error(`${operationName} failed after ${retries} attempts: ${lastError?.message}`);
}
/**
 * DynamoDBにアイテムを保存（Put操作）
 */
async function putItem(tableName, item, autoTimestamp = true) {
    const timestamp = new Date().toISOString();
    // タイムスタンプの自動記録
    const itemWithTimestamp = autoTimestamp
        ? {
            ...item,
            createdAt: item.createdAt || timestamp,
            updatedAt: timestamp,
        }
        : item;
    const params = {
        TableName: tableName,
        Item: itemWithTimestamp,
    };
    await retryWithBackoff(async () => {
        const command = new lib_dynamodb_1.PutCommand(params);
        await docClient.send(command);
        logger_1.logger.info('Item saved successfully', {
            tableName,
            itemKey: item.email || item.sessionId || 'unknown',
        });
    }, `putItem to ${tableName}`, MAX_RETRIES);
}
/**
 * DynamoDBからアイテムを取得（Get操作）
 */
async function getItem(tableName, key) {
    const params = {
        TableName: tableName,
        Key: key,
    };
    return await retryWithBackoff(async () => {
        const command = new lib_dynamodb_1.GetCommand(params);
        const result = await docClient.send(command);
        if (result.Item) {
            logger_1.logger.info('Item retrieved successfully', {
                tableName,
                key,
            });
            return result.Item;
        }
        logger_1.logger.info('Item not found', {
            tableName,
            key,
        });
        return null;
    }, `getItem from ${tableName}`, MAX_RETRIES);
}
/**
 * DynamoDBのアイテムを更新（Update操作）
 */
async function updateItem(tableName, key, updates, autoTimestamp = true) {
    // タイムスタンプの自動記録
    const updatesWithTimestamp = autoTimestamp
        ? {
            ...updates,
            updatedAt: new Date().toISOString(),
        }
        : updates;
    // UpdateExpressionとExpressionAttributeValuesを構築
    const updateExpressions = [];
    const expressionAttributeValues = {};
    const expressionAttributeNames = {};
    Object.keys(updatesWithTimestamp).forEach((key, index) => {
        const placeholder = `:val${index}`;
        const namePlaceholder = `#attr${index}`;
        updateExpressions.push(`${namePlaceholder} = ${placeholder}`);
        expressionAttributeValues[placeholder] = updatesWithTimestamp[key];
        expressionAttributeNames[namePlaceholder] = key;
    });
    const params = {
        TableName: tableName,
        Key: key,
        UpdateExpression: `SET ${updateExpressions.join(', ')}`,
        ExpressionAttributeValues: expressionAttributeValues,
        ExpressionAttributeNames: expressionAttributeNames,
    };
    await retryWithBackoff(async () => {
        const command = new lib_dynamodb_1.UpdateCommand(params);
        await docClient.send(command);
        logger_1.logger.info('Item updated successfully', {
            tableName,
            key,
            updatedFields: Object.keys(updatesWithTimestamp),
        });
    }, `updateItem in ${tableName}`, MAX_RETRIES);
}
/**
 * DynamoDBテーブルをスキャン（Scan操作）
 */
async function scanTable(tableName, filterExpression, expressionAttributeValues) {
    const params = {
        TableName: tableName,
        FilterExpression: filterExpression,
        ExpressionAttributeValues: expressionAttributeValues,
    };
    return await retryWithBackoff(async () => {
        const command = new lib_dynamodb_1.ScanCommand(params);
        const result = await docClient.send(command);
        const items = (result.Items || []);
        logger_1.logger.info('Table scanned successfully', {
            tableName,
            itemCount: items.length,
        });
        return items;
    }, `scanTable ${tableName}`, MAX_RETRIES);
}
/**
 * セッションをSessionsテーブルに保存
 */
async function saveSession(sessionId, email, role, expiresInSeconds = 86400 // デフォルト24時間
) {
    const now = Math.floor(Date.now() / 1000);
    const expiresAt = now + expiresInSeconds;
    await putItem(process.env.SESSIONS_TABLE || 'teamviewer-survey-sessions', {
        sessionId,
        email,
        role,
        createdAt: now,
        expiresAt,
    }, false // タイムスタンプは手動で設定（Unix時間を使用）
    );
}
/**
 * セッションをSessionsテーブルから取得
 */
async function getSession(sessionId) {
    return await getItem(process.env.SESSIONS_TABLE || 'teamviewer-survey-sessions', { sessionId });
}
/**
 * アンケート回答をResponsesテーブルに保存
 */
async function saveResponse(email, responses) {
    // 既存の回答を取得
    const existingResponse = await getResponse(email);
    if (existingResponse) {
        // 既存の回答がある場合は更新
        const mergedResponses = {
            ...existingResponse.responses,
            ...responses,
        };
        await updateItem(process.env.RESPONSES_TABLE || 'teamviewer-survey-responses', { email }, { responses: mergedResponses });
    }
    else {
        // 新規回答の場合は作成
        await putItem(process.env.RESPONSES_TABLE || 'teamviewer-survey-responses', {
            email,
            responses,
        });
    }
}
/**
 * アンケート回答をResponsesテーブルから取得
 */
async function getResponse(email) {
    return await getItem(process.env.RESPONSES_TABLE || 'teamviewer-survey-responses', { email });
}
/**
 * すべてのアンケート回答を取得（レポート生成用）
 */
async function getAllResponses() {
    return await scanTable(process.env.RESPONSES_TABLE || 'teamviewer-survey-responses');
}
//# sourceMappingURL=dynamodb.js.map