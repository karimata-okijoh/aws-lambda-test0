import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * レポート生成Lambda関数ハンドラー
 * 要件: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6
 */
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=report.d.ts.map